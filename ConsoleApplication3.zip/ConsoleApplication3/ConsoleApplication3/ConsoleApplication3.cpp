#include <iostream>
#include <vector>
#include <string>
using namespace std;
class Pilot; // define before using in Pilot Class

class Engine {
    string _model;
    unsigned short _horsePower;
public:
    Engine(string model, unsigned short horsePower)
    {
        this->_model = model;
        this->_horsePower = horsePower;
    }
    void Start() {
        cout << "Engine (" << this->_model << ") started ...";
    }
};
    class RaceCar {
        string _model;
        Engine* _engine;
    public:


 

        RaceCar(string model, Engine* engine)
        {
            this->_model = model;
            this->_engine = engine;
        }
        string GetModel() 
        {
            return this->_model;
        }
        
    };




   class Pilot {
       string _name;
       string _surname;
       string _nationality;
       unsigned _trophies;
       F1_team* _team;
   public:
          Pilot(string name, string surname, string nationality, unsigned short trophies, F1_team* team)
          {
              this->_name = name;
              this->_surname = surname;
              this->_trophies = trophies;
              this->_team = team;
          };
          void DisplayPilot() {
              cout << "Name: " << this->_name << endl
                  << "Surname: " << this->_surname << endl
                  << "Team: " << this->_team << endl;
          };
   };
   class F1_team {
       string _name;
       unsigned short _workersCount;
       vector<Pilot*> _pilots;

   public:
       F1_team(string name , int workersCount)
       {
           this->_name = name;
           this->_workersCount = workersCount;
       }
       void AddPilot(Pilot* pilot)
       {
           _pilots.push_back(pilot);
       }
       string GetName() {
           return this->_name;
       }
       void DisplayTeam() {
           cout << "Team: " << this->_name << endl;
           cout << "Pilots: " << endl;
           for (auto& pilot  : _pilots)
           {
               pilot->DisplayPilot();
           }
           
       }
   };
   
  
  class Garage {
      F1_team* _team;
      vector<RaceCar*> _raceCars;

  public:
      Garage(F1_team* team)
      {
          this->_team = team;
      }
      void AddCartoGarage(RaceCar* raceCar)
      {
          _raceCars.push_back(raceCar);
      }

      void ShowCarsbyTeam(string& teamName) {
          if (this->_team->GetName() == teamName) {
              for (auto& car : _raceCars)
              {
                  cout << "Car: " << car->GetModel() << endl;
              }
          }
      }
  };


  int main() {
      Engine* engine1 = new Engine("V8 twin turbo", 1000);

      RaceCar* car1 = new RaceCar("mercedes", engine1);

      F1_team* team1 = new F1_team("red bull race", 1);

      Pilot* pilot1 = new Pilot("likleyr", "baba", "azerbaycanli", 20, team1);

      team1->AddPilot(pilot1);

      Garage* garage1 = new Garage(team1);

      garage1->AddCartoGarage(car1);

      team1->DisplayTeam();

      string teamName = "red bull race";
      garage1->ShowCarsbyTeam(teamName);

      
      return 0;
      }
  

  
